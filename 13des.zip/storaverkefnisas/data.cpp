//
//  data.cpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 04/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//
#include <fstream>
#include <vector>
#include "data.hpp"
#include <string>
Data::Data(){}
//const int MAX_SIZE = 100000;




 void Data::add_topping(Topping& topping){
 vector<string> tempmeat = topping.getMeatTopping();
 vector<string> tempspice = topping.getspiceToppings();
 vector<string> tempveggies = topping.getveggiesToppings();
 vector<string> tempcheese = topping.getCheeseToppings();
     cout << "KjötAlegg: ";
     for (int i = 0; i < tempmeat.size(); i++){
         cout << tempmeat[i] << " - ";
     }
  ofstream fout;
  fout.open("topping.txt",ios::app);
     if (fout.is_open()) {
         fout << "Nafn kjotaleggs: \n ";
         for (int i = 0; i < tempmeat.size(); i++){
             fout << tempmeat[i] << " - ";
         }
         fout << " \n \n -";
         fout << "Nafn krydd: \n ";
         for (int i = 0; i < tempspice.size(); i++){
             fout << tempspice[i] << " - ";
         }
         fout << " \n \n -";
         fout << "Nafn graenmeti:  \n ";
         for (int i = 0; i < tempveggies.size(); i++){
             fout << tempveggies[i] << " - ";
         }
         fout << " \n \n -";
         fout << "Nafn ostur: \n ";
         for (int i = 0; i < tempcheese.size(); i++){
             fout << tempcheese[i] << " - ";
         }
         fout << " \n \n -";
         
         fout.close();
         
         
         
     }
 
 }


 void Data::add_pizza(Pizza& pizza){
  // char str[MAX_SIZE];
     vector<string> temp = pizza.gettoppings();
     cout << "Name: " << pizza.getName() << endl;
     cout << "Size: " << pizza.getsize() << endl;
     cout << "Verd" << pizza.getverd() << endl;
     cout << "Alegg: ";
     for (int i = 0; i < temp.size(); i++){
         cout << temp[i] << " - ";
     }
     
     ofstream fout;
   
     cout << "Hello, can you something below me???" << endl;
     fout.open("pizza.txt",ios::app);
     if (fout.is_open()) {
      //   cin.getline(str, MAX_SIZE);
     //     string tempi = str;
         fout << "Nafn pizzu: " << pizza.getName() << " \n" << "Stærð pizzu: " << pizza.getsize() << "tommur " <<"\n" << "Pizza kostar: " <<pizza.getverd() << "kr \n Álegg: ";
         for (int i = 0; i < temp.size(); i++){
             fout << temp[i] << ", ";
         }
         fout << " \n \n -";
         
         fout.close();
     }
     else{
        ///throw error
     }
     
 }

 void Data::add_order(OrderModelClass& order){
     double sum = 0;
     string name = order.getName();
     int size = order.getsize();
     string botn = order.getbotn();
     ofstream fout;
     vector<double> kronur = order.getverd();
  fout.open("order.txt",ios::app);
     if (fout.is_open()) {
         fout  << name << "|" << size << "|" << botn << "|" << endl;
 
  
  
  for (int i = 0; i < kronur.size(); i++){
 
    
      
  sum += kronur[i];
      fout << sum << endl;
  }
  
 
 fout << " \n \n -";
 
 fout.close();
 }
 else{
 ///throw error
 }
 
 
 
 
 
 }
void Data::add_topping_order(OrderModelClass& order){
    double sum = 0;
   
    int size = order.getsize();
    string botn = order.getbotn();
    vector<string> topping = order.getTopping();
    ofstream fout;
    vector<double> kronur = order.getverd();
    fout.open("order.txt",ios::app);
    if (fout.is_open()) {
        fout   << size << "|" << botn << "|" << endl;
        
        cout << "Size of vector is: " << topping.size() << endl;
        for (int i = 0; i < topping.size(); i++){
            fout << topping[i] << " - ";
        }
        fout << " \n \n -";
        
        for (int i = 0; i < kronur.size(); i++){
            
            
            
          sum += kronur[i];
        fout << sum << endl;
       }
        
        
       fout << " \n \n -";
        
        fout.close();
    }
    else{
        ///throw error
    }
    
    
    
    
    
}














/*void Data::add_topping(Topping& topping){
      vector<string> tempa = topping.getMeatTopping();
    vector<string> tempb = topping.getspiceToppings();
    vector<string> tempc = topping.getveggiesToppings();
    vector<string> tempd = topping.getCheeseToppings();
    cout << "testfor this add topping" << endl;
    
}
*/
// void Data::getpizza(Pizza& pizza){
    
//    ifstream fin;
    
//    cout << "Hello, can you something below me???" << endl;
 //   fin.open("pizza.txt");
   // if (fin.is_open()) {
        //   cin.getline(str, MAX_SIZE);
        //     string tempi = str;
     //   fin >> pizza;
      //  fin.close();
  //  }
   // else{
        ///throw error
   // }
// }

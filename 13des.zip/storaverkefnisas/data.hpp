//
//  data.hpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 04/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#ifndef data_hpp
#define data_hpp
#include <stdio.h>
#include "Pizza.hpp"
#include "OrderModelClass.hpp"
class Data {
private:



public:
    Data();
    void add_pizza(Pizza& pizza);
    void add_topping(Topping& topping);
    void getpizza(Pizza& pizza);
    void add_order(OrderModelClass& order);
    void add_topping_order(OrderModelClass& order);
};




#endif /* data_hpp */

//
//  OrderModelClass.cpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 11/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#include "OrderModelClass.hpp"

OrderModelClass::OrderModelClass(){
    
}
OrderModelClass::OrderModelClass(string location){
    this->location = location;
}


OrderModelClass::OrderModelClass(string nafnPizzu, int staerd, string botn, vector<double> price,  bool thisIsFalse){
    
    this -> nafnPizzu = nafnPizzu;
    this -> staerdPizzu = staerd;
    this -> botn = botn;
    this -> verd = price;
   this -> finishedOrNot = thisIsFalse; 
    
    
    for (int i = 0; i < verd.size(); ++i)
    {
        finalVerd += verd[i];
    }
}
OrderModelClass::OrderModelClass(int staerd, string botn,vector<string> toppings, vector<double> price,  bool thisIsFalse){
    
    this -> staerdPizzu = staerd;
    this -> botn = botn;
    this -> toppings =toppings;
    this -> verd = price;
    this -> finishedOrNot = thisIsFalse;
    
    for (int i = 0; i < verd.size(); ++i)
    {
        finalVerd += verd[i];
    }
}


string OrderModelClass::getlocation(){
    return location;
}

string OrderModelClass::getName(){
    return nafnPizzu;
}
int OrderModelClass::getsize(){
    return staerdPizzu;
}
string OrderModelClass::getbotn(){
    return botn;
}
vector <double> OrderModelClass::getverd(){
    
    
    return verd;
}
vector <string> OrderModelClass::getTopping(){
    return toppings;
}


void OrderModelClass::setName(string name){
    nafnPizzu = name;
}
void OrderModelClass::setsize(int staerd){
    staerdPizzu = staerd;
}
void OrderModelClass::setbotn(string b){
    botn = b;
    
}
void OrderModelClass::setprice(vector<double> verd){
    this-> verd = verd;
}

double OrderModelClass::getFinalVerd()
{
    return this->finalVerd;
}

void OrderModelClass::setFinalVerd(double verd){
    finalVerd = verd;
}

bool OrderModelClass::getDoneOrNot(){
    return finishedOrNot;
}
void OrderModelClass::setDoneOrNot(bool change){
    finishedOrNot = change;
}

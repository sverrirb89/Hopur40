//
//  WholeOrder.hpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 14/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#ifndef WholeOrder_hpp
#define WholeOrder_hpp

#include <stdio.h>
#include "OrderModelClass.hpp"
using namespace std;
#endif /* WholeOrder_hpp */

class WholeOrderClass {
    public:
    string getAfangastadur();
    bool getDoneOrNot();
    double getFinalVerd();
    vector<OrderModelClass> getWholeOrder();
    void setAfangastadur(string newAfangastadur);
    void setDoneOrNot(bool shouldBeDoneNow);
    void setWholeOrder(vector<OrderModelClass> newWholeOrder);
    
    private:
    string afangastadur;
    bool doneOrNot;
    double finalVerd;
    vector<OrderModelClass> wholeOrder;
};

//
//  OrderModelClass.hpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 11/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#ifndef OrderModelClass_hpp
#define OrderModelClass_hpp
#include <string>
#include <vector>
#include <stdio.h>
#include "Pizza.hpp"
#include "Topping.hpp"
using namespace std;

class OrderModelClass {
    
    
public:
    OrderModelClass();
    OrderModelClass(string nafnPizzu, int staerd, string botn, vector<double> price, bool thisIsFalse);
    OrderModelClass(int staerd, string botn,vector<string> toppings, vector<double> price, bool thisIsFalse);
    //   OrderModelClass(int staerd, string botn, ); 
    OrderModelClass(string location);
    vector <string> getTopping();
    //get og set skipanir
    string getlocation();
    string getName();
    void setName(string name);
    void setsize(int staerd);
    void setbotn(string b);
    void setprice(vector<double> verd);
    int getsize();
    string getbotn();
    vector <double> getverd();
    double getFinalVerd();
    void setFinalVerd(double verd);
    bool getDoneOrNot();
    void setDoneOrNot(bool change);
private:
    string nafnPizzu;
    int staerdPizzu;
    string botn;
    vector<double> verd;
    string location;
    vector<string> toppings;
    double finalVerd;
    bool finishedOrNot;
    //vector<toppings> á pizzuna
};

#endif /* OrderModelClass_hpp */

//
//  WholeOrder.cpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 14/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#include "WholeOrder.hpp"

string WholeOrderClass::getAfangastadur(){
    return afangastadur;
}
bool WholeOrderClass::getDoneOrNot(){
    return doneOrNot;
}
double WholeOrderClass::getFinalVerd(){
    return finalVerd;
}
vector<OrderModelClass> WholeOrderClass::getWholeOrder(){
    return wholeOrder;
}
void WholeOrderClass::setAfangastadur(string newAfangastadur){
    afangastadur = newAfangastadur;
}
void WholeOrderClass::setDoneOrNot(bool shouldBeDoneNow){
    doneOrNot = shouldBeDoneNow;
}
void WholeOrderClass::setWholeOrder(vector<OrderModelClass> newWholeOrder){
    wholeOrder = newWholeOrder;
}

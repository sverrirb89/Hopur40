//
//  main.cpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 04/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#include <iostream>
#include "Userinterface.hpp"
#include "Pizza.hpp"
int main(int argc, const char * argv[]) {
    
   Userinterface ui;
    
   ui.veldunotanda();
    
    Pizzaservices pizza_services;
    
    return 0;
}

//
//  data.hpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 04/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#ifndef data_hpp
#define data_hpp
#include <stdio.h>
#include "Pizza.hpp"
#include "OrderModelClass.hpp"
#include "WholeOrder.hpp"
class Data {
private:
    WholeOrderClass allOrders;

public:
    
    Data();
    void populateVectorOfAllOrders();
    void add_pizza(Pizza& pizza);
    void add_topping(Topping& topping);
    void getpizza(Pizza& pizza);
    void add_order(OrderModelClass& order);
    void add_topping_order(OrderModelClass& order);
    void add_location(OrderModelClass& order);
    void addprice(OrderModelClass& order);
    void getorder();
    void get_pizza_menu();
    void get_topping_menu();
};




#endif /* data_hpp */

//
//  salesmanservices.cpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 10/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#include "salesmanservices.hpp"

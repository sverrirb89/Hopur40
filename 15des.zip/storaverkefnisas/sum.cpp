//
//  sum.cpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 13/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#include "sum.hpp"


int sum(int a, int b)
{
    return(a+b);
}

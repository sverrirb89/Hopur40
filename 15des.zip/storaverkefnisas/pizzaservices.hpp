//
//  pizzaservices.hpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 05/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#ifndef pizzaservices_hpp
#define pizzaservices_hpp
//#include "Userinterface.hpp"
#include "Pizza.hpp"
#include <stdio.h>
#include "data.hpp"
#include "OrderModelClass.hpp"
class Pizzaservices {
    
public:
    Pizzaservices();
    void add_pizza(Pizza& pizza);
 //   Data add_pizza(Pizza& pizza);
    void add_topping(Topping& topping);
    void add_order(OrderModelClass& order);
     void add_topping_order(OrderModelClass& order);
    void add_location(OrderModelClass& order);
    void addprice(OrderModelClass& order);
    void getorder();
    void getpizza();
    void gettopping();
    void tempFunction();
};



#endif /* pizzaservices_hpp */

//
//  sum.hpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 13/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#ifndef sum_hpp
#define sum_hpp

#include <stdio.h>


int sum(int a, int b);

class sum
{
    
public:
    sum(void);
    ~sum(void);
    
};



#endif /* sum_hpp */

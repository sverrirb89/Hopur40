//
//  salesmanservices.hpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 10/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#ifndef salesmanservices_hpp
#define salesmanservices_hpp
#include "data.hpp"



#include <stdio.h>

#endif /* salesmanservices_hpp */

//
//  data.cpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 04/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//
#include <fstream>
#include <vector>
#include "data.hpp"
#include <string>
Data::Data(){}
//const int MAX_SIZE = 100000;




 void Data::add_topping(Topping& topping){
 vector<string> tempmeat = topping.getMeatTopping();
 vector<string> tempspice = topping.getspiceToppings();
 vector<string> tempveggies = topping.getveggiesToppings();
 vector<string> tempcheese = topping.getCheeseToppings();
     cout << "KjötAlegg: ";
     for (int i = 0; i < tempmeat.size(); i++){
         cout << tempmeat[i] << " - ";
     }
  ofstream fout;
  fout.open("topping.txt",ios::app);
     if (fout.is_open()) {
         fout << "Nafn kjotaleggs: \n ";
         for (int i = 0; i < tempmeat.size(); i++){
             fout << tempmeat[i] << " - ";
         }
         fout << " \n \n -";
         
         fout.close();
         
         
         
     }
 
 }


 void Data::add_pizza(Pizza& pizza){
  // char str[MAX_SIZE];
     vector<string> temp = pizza.gettoppings();
     cout << "Name: " << pizza.getName() << endl;
     cout << "Size: " << pizza.getsize() << endl;
     cout << "Verd" << pizza.getverd() << endl;
     cout << "Alegg: ";
     for (int i = 0; i < temp.size(); i++){
         cout << temp[i] << " - ";
     }
     
     ofstream fout;
   
     cout << "Hello, can you something below me???" << endl;
     fout.open("pizza.txt",ios::app);
     if (fout.is_open()) {
      //   cin.getline(str, MAX_SIZE);
     //     string tempi = str;
         fout << "Nafn pizzu: " << pizza.getName() << " \n" << "Stærð pizzu: " << pizza.getsize() << "tommur " <<"\n" << "Pizza kostar: " <<pizza.getverd() << "kr \n Álegg: ";
         for (int i = 0; i < temp.size(); i++){
             fout << temp[i] << ", ";
         }
         fout << " \n \n -";
         
         fout.close();
     }
     else{
        ///throw error
     }
     
 }

/*void Data::add_topping(Topping& topping){
      vector<string> tempa = topping.getMeatTopping();
    vector<string> tempb = topping.getspiceToppings();
    vector<string> tempc = topping.getveggiesToppings();
    vector<string> tempd = topping.getCheeseToppings();
    cout << "testfor this add topping" << endl;
    
}
*/

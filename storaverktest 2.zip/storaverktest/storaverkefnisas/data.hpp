//
//  data.hpp
//  storaverkefnisas
//
//  Created by sverrir torfason on 04/12/2017.
//  Copyright © 2017 sverrir torfason. All rights reserved.
//

#ifndef data_hpp
#define data_hpp
#include <stdio.h>
#include "Pizza.hpp"
class Data {
private:



public:
    Data();
    void add_pizza(Pizza& pizza);
    void add_topping(Topping& topping);
};




#endif /* data_hpp */
